import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Static movie details
const movieDetails: Record<number, any> = {
  1: { genres: ["Drama"], runtime: "142 min", cast: ["Tim Robbins", "Morgan Freeman", "Bob Gunton"], director: "Frank Darabont" },
  2: { genres: ["Drama", "Crime"], runtime: "175 min", cast: ["Marlon Brando", "Al Pacino", "James Caan"], director: "Francis Ford Coppola" },
  3: { genres: ["Action", "Crime", "Drama"], runtime: "152 min", cast: ["Christian Bale", "Heath Ledger", "Aaron Eckhart"], director: "Christopher Nolan" },
  4: { genres: ["Action", "Sci-Fi", "Thriller"], runtime: "148 min", cast: ["Leonardo DiCaprio", "Joseph Gordon-Levitt", "Ellen Page"], director: "Christopher Nolan" },
  5: { genres: ["Thriller", "Crime"], runtime: "154 min", cast: ["John Travolta", "Samuel L. Jackson", "Uma Thurman"], director: "Quentin Tarantino" },
  6: { genres: ["Drama", "Romance"], runtime: "142 min", cast: ["Tom Hanks", "Robin Wright", "Gary Sinise"], director: "Robert Zemeckis" },
  7: { genres: ["Action", "Sci-Fi"], runtime: "136 min", cast: ["Keanu Reeves", "Laurence Fishburne", "Carrie-Anne Moss"], director: "Lana Wachowski" },
  8: { genres: ["Adventure", "Drama", "Sci-Fi"], runtime: "169 min", cast: ["Matthew McConaughey", "Anne Hathaway", "Jessica Chastain"], director: "Christopher Nolan" },
  9: { genres: ["Drama", "Crime"], runtime: "146 min", cast: ["Robert De Niro", "Ray Liotta", "Joe Pesci"], director: "Martin Scorsese" },
  10: { genres: ["Crime", "Drama", "Thriller"], runtime: "118 min", cast: ["Jodie Foster", "Anthony Hopkins", "Lawrence A. Bonney"], director: "Jonathan Demme" },
  11: { genres: ["Drama"], runtime: "139 min", cast: ["Brad Pitt", "Edward Norton", "Meat Loaf"], director: "David Fincher" },
  12: { genres: ["Drama", "Mystery", "Sci-Fi"], runtime: "130 min", cast: ["Christian Bale", "Hugh Jackman", "Scarlett Johansson"], director: "Christopher Nolan" },
  13: { genres: ["Action", "Drama", "Adventure"], runtime: "155 min", cast: ["Russell Crowe", "Joaquin Phoenix", "Connie Nielsen"], director: "Ridley Scott" },
  14: { genres: ["Action", "Adventure", "Fantasy", "Sci-Fi"], runtime: "162 min", cast: ["Sam Worthington", "Zoe Saldana", "Sigourney Weaver"], director: "James Cameron" },
  15: { genres: ["Drama", "Romance"], runtime: "194 min", cast: ["Leonardo DiCaprio", "Kate Winslet", "Billy Zane"], director: "James Cameron" },
  
  101: { genres: ["Comedy", "Drama"], runtime: "170 min", cast: ["Aamir Khan", "R. Madhavan", "Sharman Joshi"], director: "Rajkumar Hirani" },
  102: { genres: ["Action", "Drama"], runtime: "161 min", cast: ["Aamir Khan", "Sakshi Tanwar", "Fatima Sana Shaikh"], director: "Nitesh Tiwari" },
  103: { genres: ["Drama"], runtime: "165 min", cast: ["Darsheel Safary", "Aamir Khan", "Tisca Chopra"], director: "Aamir Khan" },
  104: { genres: ["Drama", "Adventure"], runtime: "224 min", cast: ["Aamir Khan", "Gracy Singh", "Rachel Shelley"], director: "Ashutosh Gowariker" },
  105: { genres: ["Comedy", "Drama", "Sci-Fi"], runtime: "153 min", cast: ["Aamir Khan", "Anushka Sharma", "Sanjay Dutt"], director: "Rajkumar Hirani" },
  106: { genres: ["Comedy", "Drama", "Romance"], runtime: "183 min", cast: ["Aamir Khan", "Saif Ali Khan", "Akshaye Khanna"], director: "Farhan Akhtar" },
  107: { genres: ["Drama", "Comedy"], runtime: "155 min", cast: ["Hrithik Roshan", "Farhan Akhtar", "Abhay Deol"], director: "Zoya Akhtar" },
  108: { genres: ["Comedy", "Drama"], runtime: "157 min", cast: ["Aamir Khan", "Siddharth", "Sharman Joshi"], director: "Rakeysh Omprakash Mehra" },
  109: { genres: ["Thriller", "Crime"], runtime: "139 min", cast: ["Ayushmann Khurrana", "Tabu", "Radhika Apte"], director: "Sriram Raghavan" },
  110: { genres: ["Thriller", "Mystery"], runtime: "122 min", cast: ["Vidya Balan", "Parambrata Chatterjee", "Nawazuddin Siddiqui"], director: "Sujoy Ghosh" },
  111: { genres: ["Action", "Crime", "Drama"], runtime: "160 min", cast: ["Manoj Bajpayee", "Nawazuddin Siddiqui", "Tigmanshu Dhulia"], director: "Anurag Kashyap" },
  112: { genres: ["Drama", "Comedy"], runtime: "146 min", cast: ["Kangana Ranaut", "Rajkummar Rao", "Lisa Haydon"], director: "Vikas Bahl" },
  113: { genres: ["Comedy", "Drama", "Romance"], runtime: "151 min", cast: ["Ranbir Kapoor", "Priyanka Chopra", "Ileana D'Cruz"], director: "Anurag Basu" },
  114: { genres: ["Drama"], runtime: "153 min", cast: ["Shah Rukh Khan", "Vidya Malvade", "Sagarika Ghatge"], director: "Shimit Amin" },
  115: { genres: ["Drama"], runtime: "189 min", cast: ["Shah Rukh Khan", "Gayatri Joshi", "Kishori Ballal"], director: "Ashutosh Gowariker" },

  201: { genres: ["Crime", "Drama", "Thriller"], runtime: "160 min", cast: ["Mohanlal", "Meena", "Asha Sarath"], director: "Jeethu Joseph" },
  202: { genres: ["Comedy", "Drama", "Romance"], runtime: "156 min", cast: ["Nivin Pauly", "Sai Pallavi", "Madonna Sebastian"], director: "Alphonse Puthren" },
  203: { genres: ["Comedy", "Drama", "Romance"], runtime: "171 min", cast: ["Dulquer Salmaan", "Nivin Pauly", "Nazriya Nazim"], director: "Anjali Menon" },
  204: { genres: ["Drama"], runtime: "99 min", cast: ["Nimisha Sajayan", "Suraj Venjaramoodu", "T. Suresh Babu"], director: "Jeo Baby" },
  205: { genres: ["Drama", "Thriller"], runtime: "135 min", cast: ["Shane Nigam", "Soubin Shahir", "Fahadh Faasil"], director: "Madhu C. Narayanan" },
  206: { genres: ["Drama", "Thriller"], runtime: "151 min", cast: ["Parvathy Thiruvothu", "Tovino Thomas", "Kunchacko Boban"], director: "Aashiq Abu" },
  207: { genres: ["Crime", "Thriller", "Mystery"], runtime: "141 min", cast: ["Kunchacko Boban", "Sharafudheen", "Unnimaya Prasad"], director: "Midhun Manuel Thomas" },
  208: { genres: ["Comedy", "Drama"], runtime: "121 min", cast: ["Fahadh Faasil", "Anusree", "Aparna Balamurali"], director: "Dileesh Pothan" },
  209: { genres: ["Drama", "Thriller"], runtime: "132 min", cast: ["Fahadh Faasil", "Nazriya Nazim", "Soubin Shahir"], director: "Anwar Rasheed" },
  210: { genres: ["Drama", "Thriller"], runtime: "140 min", cast: ["Parvathy Thiruvothu", "Kunchacko Boban", "Fahadh Faasil"], director: "Mahesh Narayanan" },
  211: { genres: ["Crime", "Drama", "Thriller"], runtime: "119 min", cast: ["Fahadh Faasil", "Baburaj", "Shammi Thilakan"], director: "Dileesh Pothan" },
  212: { genres: ["Drama"], runtime: "138 min", cast: ["Parvathy Thiruvothu", "Asif Ali", "Tovino Thomas"], director: "Manu Ashokan" },
  213: { genres: ["Action", "Crime", "Drama"], runtime: "177 min", cast: ["Dulquer Salmaan", "Vinayakan", "Manikandan R. Achari"], director: "Rajeev Ravi" },
  214: { genres: ["Adventure", "Comedy", "Romance"], runtime: "132 min", cast: ["Dulquer Salmaan", "Parvathy Thiruvothu", "Aparna Gopinath"], director: "Martin Prakkat" },
  215: { genres: ["Romance", "Comedy"], runtime: "157 min", cast: ["Shane Nigam", "Ann Sheetal", "Shine Tom Chacko"], director: "Anuraj Manohar" },
};

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { movieId } = await req.json();
    
    console.log("Fetching movie details for:", movieId);

    const details = movieDetails[movieId];
    
    if (!details) {
      throw new Error("Movie not found");
    }

    const movieData = {
      id: movieId,
      genres: details.genres,
      runtime: details.runtime,
      cast: details.cast,
      director: details.director
    };

    return new Response(JSON.stringify(movieData), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error in get-movie-details function:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
