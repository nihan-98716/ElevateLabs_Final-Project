import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Headers": "authorization, x-client-info, apikey, content-type",
};

// Static movie database with popular English, Hindi, and Malayalam films
const movieDatabase = [
  // English Movies
  { id: 1, title: "The Shawshank Redemption", posterUrl: "https://image.tmdb.org/t/p/w500/q6y0Go1tsGEsmtFryDOJo3dEmqu.jpg", rating: "9.3", year: 1994, overview: "Two imprisoned men bond over a number of years, finding solace and eventual redemption through acts of common decency.", language: "en", genreIds: [18] },
  { id: 2, title: "The Godfather", posterUrl: "https://image.tmdb.org/t/p/w500/3bhkrj58Vtu7enYsRolD1fZdja1.jpg", rating: "9.2", year: 1972, overview: "The aging patriarch of an organized crime dynasty transfers control of his clandestine empire to his reluctant son.", language: "en", genreIds: [18, 80] },
  { id: 3, title: "The Dark Knight", posterUrl: "https://image.tmdb.org/t/p/w500/qJ2tW6WMUDux911r6m7haRef0WH.jpg", rating: "9.0", year: 2008, overview: "When the menace known as the Joker wreaks havoc and chaos on the people of Gotham, Batman must accept one of the greatest psychological and physical tests.", language: "en", genreIds: [28, 80, 18] },
  { id: 4, title: "Inception", posterUrl: "https://image.tmdb.org/t/p/w500/9gk7adHYeDvHkCSEqAvQNLV5Uge.jpg", rating: "8.8", year: 2010, overview: "A thief who steals corporate secrets through dream-sharing technology is given the inverse task of planting an idea.", language: "en", genreIds: [28, 878, 53] },
  { id: 5, title: "Pulp Fiction", posterUrl: "https://image.tmdb.org/t/p/w500/d5iIlFn5s0ImszYzBPb8JPIfbXD.jpg", rating: "8.9", year: 1994, overview: "The lives of two mob hitmen, a boxer, a gangster and his wife intertwine in four tales of violence and redemption.", language: "en", genreIds: [53, 80] },
  { id: 6, title: "Forrest Gump", posterUrl: "https://image.tmdb.org/t/p/w500/arw2vcBveWOVZr6pxd9XTd1TdQa.jpg", rating: "8.8", year: 1994, overview: "The presidencies of Kennedy and Johnson, the Vietnam War, and other historical events unfold from the perspective of an Alabama man.", language: "en", genreIds: [18, 10749] },
  { id: 7, title: "The Matrix", posterUrl: "https://image.tmdb.org/t/p/w500/f89U3ADr1oiB1s9GkdPOEpXUk5H.jpg", rating: "8.7", year: 1999, overview: "A computer hacker learns from mysterious rebels about the true nature of his reality and his role in the war against its controllers.", language: "en", genreIds: [28, 878] },
  { id: 8, title: "Interstellar", posterUrl: "https://image.tmdb.org/t/p/w500/gEU2QniE6E77NI6lCU6MxlNBvIx.jpg", rating: "8.6", year: 2014, overview: "A team of explorers travel through a wormhole in space in an attempt to ensure humanity's survival.", language: "en", genreIds: [12, 18, 878] },
  { id: 9, title: "Goodfellas", posterUrl: "https://image.tmdb.org/t/p/w500/aKuFiU82s5ISJpGZp7YkIr3kCUd.jpg", rating: "8.7", year: 1990, overview: "The story of Henry Hill and his life in the mob, covering his relationship with his wife and his partners.", language: "en", genreIds: [18, 80] },
  { id: 10, title: "The Silence of the Lambs", posterUrl: "https://image.tmdb.org/t/p/w500/uS9m8OBk1A8eM9I042bx8XXpqAq.jpg", rating: "8.6", year: 1991, overview: "A young FBI cadet must receive the help of an incarcerated cannibal killer to catch another serial killer.", language: "en", genreIds: [80, 18, 53] },
  { id: 11, title: "Fight Club", posterUrl: "https://image.tmdb.org/t/p/w500/pB8BM7pdSp6B6Ih7QZ4DrQ3PmJK.jpg", rating: "8.8", year: 1999, overview: "An insomniac office worker and a devil-may-care soapmaker form an underground fight club.", language: "en", genreIds: [18] },
  { id: 12, title: "The Prestige", posterUrl: "https://image.tmdb.org/t/p/w500/tRNlZbgNCNOpLpbPEz5L8G8A0JN.jpg", rating: "8.5", year: 2006, overview: "After a tragic accident, two stage magicians engage in a battle to create the ultimate illusion.", language: "en", genreIds: [18, 9648, 878] },
  { id: 13, title: "Gladiator", posterUrl: "https://image.tmdb.org/t/p/w500/ty8TGRuvJLPUmAR1H1nRIsgwvim.jpg", rating: "8.5", year: 2000, overview: "A former Roman General sets out to exact vengeance against the corrupt emperor who murdered his family.", language: "en", genreIds: [28, 18, 12] },
  { id: 14, title: "Avatar", posterUrl: "https://image.tmdb.org/t/p/w500/kyeqWdyUXW608qlYkRqoKGhPMh.jpg", rating: "7.8", year: 2009, overview: "A paraplegic Marine dispatched to the moon Pandora on a unique mission becomes torn between following his orders.", language: "en", genreIds: [28, 12, 14, 878] },
  { id: 15, title: "Titanic", posterUrl: "https://image.tmdb.org/t/p/w500/9xjZS2rlVxm8SFx8kPC3aIGCOYQ.jpg", rating: "7.9", year: 1997, overview: "A seventeen-year-old aristocrat falls in love with a kind but poor artist aboard the luxurious, ill-fated R.M.S. Titanic.", language: "en", genreIds: [18, 10749] },
  
  // Hindi Movies
  { id: 101, title: "3 Idiots", posterUrl: "https://image.tmdb.org/t/p/w500/66A9MqXOyVFCssoloscwgow9Nlh.jpg", rating: "8.4", year: 2009, overview: "Two friends search for their long lost companion while reflecting on their college days and the ideals they shared.", language: "hi", genreIds: [35, 18] },
  { id: 102, title: "Dangal", posterUrl: "https://image.tmdb.org/t/p/w500/lXdCVNTkiKkd0BiYg0vAw2f5YDa.jpg", rating: "8.3", year: 2016, overview: "Former wrestler Mahavir Singh Phogat trains his daughters to become world-class wrestlers.", language: "hi", genreIds: [28, 18] },
  { id: 103, title: "Taare Zameen Par", posterUrl: "https://image.tmdb.org/t/p/w500/2NRODLGorXn70B2FWV90yp6n80H.jpg", rating: "8.4", year: 2007, overview: "An eight-year-old boy is thought to be lazy and a trouble-maker, until the new art teacher discovers he has dyslexia.", language: "hi", genreIds: [18] },
  { id: 104, title: "Lagaan", posterUrl: "https://image.tmdb.org/t/p/w500/dFOqQ9QDdowCBpcDdxAJ3KK3r5R.jpg", rating: "8.1", year: 2001, overview: "The people of a small village in Victorian India stake their future on a game of cricket against their ruthless British rulers.", language: "hi", genreIds: [18, 12] },
  { id: 105, title: "PK", posterUrl: "https://image.tmdb.org/t/p/w500/hJK2RwSbgdlLUJEm9CNeRpPVLjE.jpg", rating: "8.1", year: 2014, overview: "An alien on Earth loses the only device he can use to communicate with his spaceship.", language: "hi", genreIds: [35, 18, 878] },
  { id: 106, title: "Dil Chahta Hai", posterUrl: "https://image.tmdb.org/t/p/w500/yKkEvfG8wbRILAkQslsfPZFVPTe.jpg", rating: "8.1", year: 2001, overview: "Three inseparable childhood friends are just out of college. Nothing comes between them until they each fall in love.", language: "hi", genreIds: [35, 18, 10749] },
  { id: 107, title: "Zindagi Na Milegi Dobara", posterUrl: "https://image.tmdb.org/t/p/w500/8tW0MlNDVhxWe6gYUK4Tz2j6L67.jpg", rating: "8.2", year: 2011, overview: "Three friends decide to turn their fantasy vacation into reality after one of their friends gets engaged.", language: "hi", genreIds: [18, 35] },
  { id: 108, title: "Rang De Basanti", posterUrl: "https://image.tmdb.org/t/p/w500/fmXBsNq3N9TxXmiwS4P34EgKrSl.jpg", rating: "8.1", year: 2006, overview: "The story of six young Indians who assist an English woman to film a documentary on Indian freedom fighters.", language: "hi", genreIds: [35, 18] },
  { id: 109, title: "Andhadhun", posterUrl: "https://image.tmdb.org/t/p/w500/xRlfAIRH62K7UZfqkK36vFJ1CuB.jpg", rating: "8.3", year: 2018, overview: "A series of mysterious events change the life of a blind pianist who now must report a crime.", language: "hi", genreIds: [53, 80] },
  { id: 110, title: "Kahaani", posterUrl: "https://image.tmdb.org/t/p/w500/3qxJ9YqNJvJNPMPBqgzYQe4Qlqv.jpg", rating: "8.1", year: 2012, overview: "A pregnant woman's search for her missing husband takes her from London to Kolkata.", language: "hi", genreIds: [53, 9648] },
  { id: 111, title: "Gangs of Wasseypur", posterUrl: "https://image.tmdb.org/t/p/w500/uxNHGmvhJTgKwLvMlN47llI3s6b.jpg", rating: "8.2", year: 2012, overview: "A clash between Sultan and Shahid Khan leads to the expulsion of Khan from Wasseypur.", language: "hi", genreIds: [28, 80, 18] },
  { id: 112, title: "Queen", posterUrl: "https://image.tmdb.org/t/p/w500/5sqPPxSP2VwjYQYZCgPJcc1OBCe.jpg", rating: "8.2", year: 2014, overview: "A Delhi girl from a traditional family sets out on a solo honeymoon after her marriage gets cancelled.", language: "hi", genreIds: [18, 35] },
  { id: 113, title: "Barfi!", posterUrl: "https://image.tmdb.org/t/p/w500/cDh71HPPM2vvpILCgvwKbsYMT3I.jpg", rating: "8.1", year: 2012, overview: "Three young people learn that love can neither be defined nor contained by society's norms.", language: "hi", genreIds: [35, 18, 10749] },
  { id: 114, title: "Chak De! India", posterUrl: "https://image.tmdb.org/t/p/w500/5StVLr09zDGv0qXcPZdkpCQpA5R.jpg", rating: "8.2", year: 2007, overview: "Kabir Khan is the coach of the Indian Women's National Hockey Team and his dream is to make his all-girls team emerge victorious.", language: "hi", genreIds: [18] },
  { id: 115, title: "Swades", posterUrl: "https://image.tmdb.org/t/p/w500/rhgW7tGLIx56wFpJjXljEKLlLMO.jpg", rating: "8.2", year: 2004, overview: "A successful Indian scientist returns to India to take his nanny to America but instead gets caught up in the struggle for development.", language: "hi", genreIds: [18] },

  // Malayalam Movies
  { id: 201, title: "Drishyam", posterUrl: "https://image.tmdb.org/t/p/w500/9FyrdxiJqmj4WZgwJnI9Q5DpJbr.jpg", rating: "8.6", year: 2013, overview: "A man goes to extreme lengths to save his family from punishment after the family commits an accidental crime.", language: "ml", genreIds: [80, 18, 53] },
  { id: 202, title: "Premam", posterUrl: "https://image.tmdb.org/t/p/w500/h7W8gvfhqzd0bvdDPJRjPRjQKdo.jpg", rating: "8.3", year: 2015, overview: "A young man has three opportunities to find love. Will the third time be the charm?", language: "ml", genreIds: [35, 18, 10749] },
  { id: 203, title: "Bangalore Days", posterUrl: "https://image.tmdb.org/t/p/w500/5U1BOjLgqCLDNhO0RFGBh4tGmWP.jpg", rating: "8.3", year: 2014, overview: "Three cousins, who childhood dreams of living and working together in Bangalore, achieve it but discover that their dreams don't match reality.", language: "ml", genreIds: [35, 18, 10749] },
  { id: 204, title: "The Great Indian Kitchen", posterUrl: "https://image.tmdb.org/t/p/w500/4MbDvwJfAiWJJlss4lGZ4JqxfM7.jpg", rating: "8.3", year: 2021, overview: "After marriage, a woman struggles to be the submissive wife that her husband and his family expect her to be.", language: "ml", genreIds: [18] },
  { id: 205, title: "Kumbalangi Nights", posterUrl: "https://image.tmdb.org/t/p/w500/5HM4N8T9zYSHbPsxlAQ5mXgqXZO.jpg", rating: "8.4", year: 2019, overview: "Four brothers living in a fishing village try to find love and overcome their family issues.", language: "ml", genreIds: [18, 53] },
  { id: 206, title: "Virus", posterUrl: "https://image.tmdb.org/t/p/w500/c1BJ5yKJzaNDFRCBcq4CmfgVlx8.jpg", rating: "8.1", year: 2019, overview: "A real life account of the deadly Nipah virus outbreak in Kerala, and the courageous fight put on by several individuals.", language: "ml", genreIds: [18, 53] },
  { id: 207, title: "Anjaam Pathiraa", posterUrl: "https://image.tmdb.org/t/p/w500/kVKIV0AlzL5wMHyaPnLKPJOmDMT.jpg", rating: "8.0", year: 2020, overview: "The police bring a criminologist on board to help them solve a series of brutal murders.", language: "ml", genreIds: [80, 53, 9648] },
  { id: 208, title: "Maheshinte Prathikaaram", posterUrl: "https://image.tmdb.org/t/p/w500/vUtXaYr0MsqIiXFZCRlQKPFaWgX.jpg", rating: "8.0", year: 2016, overview: "Mahesh, a studio photographer and owner of the studio decides to take revenge.", language: "ml", genreIds: [35, 18] },
  { id: 209, title: "Trance", posterUrl: "https://image.tmdb.org/t/p/w500/7q5hKz0R0aXCWRWd0u9Fvqb5MO2.jpg", rating: "7.9", year: 2020, overview: "A disheartened motivational speaker gets hired by a corporate to become a preacher until his beliefs start clashing.", language: "ml", genreIds: [18, 53] },
  { id: 210, title: "Take Off", posterUrl: "https://image.tmdb.org/t/p/w500/yqx1GuIRkPpKvqJDJy6fGFNKlR7.jpg", rating: "8.2", year: 2017, overview: "The story of a group of nurses who were held captive in Iraq.", language: "ml", genreIds: [18, 53] },
  { id: 211, title: "Joji", posterUrl: "https://image.tmdb.org/t/p/w500/2VRkkWMmPHYHFgqg4qFNi3fKyxS.jpg", rating: "7.8", year: 2021, overview: "Inspired by Macbeth, this story follows an ambitious younger son of a wealthy family.", language: "ml", genreIds: [80, 18, 53] },
  { id: 212, title: "Uyare", posterUrl: "https://image.tmdb.org/t/p/w500/hfxrEZd9lIAhLQfQvBBvSW3XVIw.jpg", rating: "8.1", year: 2019, overview: "An aspiring pilot fights for her future and the very survival of her relationship after an acid attack.", language: "ml", genreIds: [18] },
  { id: 213, title: "Kammatti Paadam", posterUrl: "https://image.tmdb.org/t/p/w500/4N8F5q7oHjjbL5EXmYSx7YHrUhm.jpg", rating: "7.9", year: 2016, overview: "A goon returns to his native place and learns about his missing buddy.", language: "ml", genreIds: [28, 80, 18] },
  { id: 214, title: "Charlie", posterUrl: "https://image.tmdb.org/t/p/w500/pQ1HrSLTyYVpFPCVa1l4K7c5I0r.jpg", rating: "7.8", year: 2015, overview: "A young, nonconforming woman named Tessa gets entangled in a cat-and-mouse chase in the by-lanes of Kerala.", language: "ml", genreIds: [12, 35, 10749] },
  { id: 215, title: "Ishq", posterUrl: "https://image.tmdb.org/t/p/w500/4zOnuYGFwKCJjzB5LjQQKYI4Xcl.jpg", rating: "7.7", year: 2019, overview: "The story revolves around two friends and their romantic relationships.", language: "ml", genreIds: [10749, 35] },
];

serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log("Fetching movies from static database");

    // Return all movies
    const movies = movieDatabase.map(movie => ({
      id: movie.id,
      title: movie.title,
      posterUrl: movie.posterUrl,
      rating: movie.rating,
      year: movie.year,
      overview: movie.overview,
      language: movie.language,
      genreIds: movie.genreIds
    }));

    console.log(`Returning ${movies.length} movies`);

    return new Response(JSON.stringify({ movies }), {
      headers: { ...corsHeaders, "Content-Type": "application/json" },
    });
  } catch (error) {
    console.error("Error in fetch-movies function:", error);
    const errorMessage = error instanceof Error ? error.message : "Unknown error";
    return new Response(
      JSON.stringify({ error: errorMessage }),
      {
        status: 500,
        headers: { ...corsHeaders, "Content-Type": "application/json" },
      }
    );
  }
});
