import { useState, useEffect } from "react";
import { MovieCard } from "@/components/MovieCard";
import { MovieModal } from "@/components/MovieModal";
import { FilterPanel } from "@/components/FilterPanel";
import { SearchBar } from "@/components/SearchBar";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { Film } from "lucide-react";

interface Movie {
  id: number;
  title: string;
  posterUrl: string;
  rating: string;
  year: string | number;
  overview: string;
  language: string;
  genreIds: number[];
}

const Index = () => {
  const [movies, setMovies] = useState<Movie[]>([]);
  const [filteredMovies, setFilteredMovies] = useState<Movie[]>([]);
  const [loading, setLoading] = useState(true);
  const [selectedMovieId, setSelectedMovieId] = useState<number | null>(null);
  const [modalOpen, setModalOpen] = useState(false);
  
  // Filter states
  const [selectedGenres, setSelectedGenres] = useState<number[]>([]);
  const [selectedLanguage, setSelectedLanguage] = useState("all");
  const [rating, setRating] = useState(0);
  const [yearRange, setYearRange] = useState<[number, number]>([1900, 2025]);
  const [searchQuery, setSearchQuery] = useState("");

  useEffect(() => {
    fetchMovies();
  }, []);

  useEffect(() => {
    applyFilters();
  }, [movies, selectedGenres, selectedLanguage, rating, yearRange, searchQuery]);

  const fetchMovies = async () => {
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('fetch-movies', {
        body: {}
      });

      if (error) throw error;
      
      setMovies(data.movies || []);
    } catch (error) {
      console.error('Error fetching movies:', error);
      toast.error('Failed to load movies. Please check if TMDB_API_KEY is configured.');
    } finally {
      setLoading(false);
    }
  };

  const applyFilters = () => {
    let filtered = [...movies];

    // Search filter
    if (searchQuery) {
      const query = searchQuery.toLowerCase();
      filtered = filtered.filter(movie => 
        movie.title.toLowerCase().includes(query)
      );
    }

    // Genre filter
    if (selectedGenres.length > 0) {
      filtered = filtered.filter(movie =>
        selectedGenres.some(genreId => movie.genreIds.includes(genreId))
      );
    }

    // Language filter
    if (selectedLanguage !== "all") {
      const languageCodes: Record<string, string> = {
        english: "en",
        hindi: "hi",
        malayalam: "ml"
      };
      filtered = filtered.filter(movie => 
        movie.language === languageCodes[selectedLanguage]
      );
    }

    // Rating filter
    if (rating > 0) {
      filtered = filtered.filter(movie => {
        const movieRating = parseFloat(movie.rating);
        return !isNaN(movieRating) && movieRating >= rating;
      });
    }

    // Year filter
    filtered = filtered.filter(movie => {
      const movieYear = typeof movie.year === 'number' ? movie.year : parseInt(movie.year);
      return !isNaN(movieYear) && movieYear >= yearRange[0] && movieYear <= yearRange[1];
    });

    setFilteredMovies(filtered);
  };

  const handleResetFilters = () => {
    setSelectedGenres([]);
    setSelectedLanguage("all");
    setRating(0);
    setYearRange([1900, 2025]);
    setSearchQuery("");
  };

  const handleMovieClick = (movieId: number) => {
    setSelectedMovieId(movieId);
    setModalOpen(true);
  };

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="bg-gradient-to-r from-primary/20 to-secondary/20 border-b border-border">
        <div className="container mx-auto px-4 py-8">
          <div className="flex items-center gap-3 mb-6 animate-fade-in">
            <Film className="w-10 h-10 text-primary" />
            <h1 className="text-4xl font-bold text-foreground">
              CineMatch
            </h1>
          </div>
          <p className="text-muted-foreground mb-6 animate-fade-in" style={{ animationDelay: "0.1s" }}>
            Discover your next favorite movie from thousands of titles
          </p>
          <div className="animate-fade-in" style={{ animationDelay: "0.2s" }}>
            <SearchBar value={searchQuery} onChange={setSearchQuery} />
          </div>
        </div>
      </header>

      <div className="container mx-auto px-4 py-8">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Filters */}
          <aside className="lg:col-span-1">
            <FilterPanel
              selectedGenres={selectedGenres}
              onGenreChange={setSelectedGenres}
              selectedLanguage={selectedLanguage}
              onLanguageChange={setSelectedLanguage}
              rating={rating}
              onRatingChange={setRating}
              yearRange={yearRange}
              onYearRangeChange={setYearRange}
              onReset={handleResetFilters}
            />
          </aside>

          {/* Movies Grid */}
          <main className="lg:col-span-3">
            {loading ? (
              <div className="flex items-center justify-center py-20">
                <div className="animate-spin rounded-full h-16 w-16 border-b-2 border-primary"></div>
              </div>
            ) : filteredMovies.length === 0 ? (
              <div className="text-center py-20">
                <p className="text-xl text-muted-foreground">
                  No movies found. Try adjusting your filters.
                </p>
              </div>
            ) : (
              <>
                <div className="mb-6 flex items-center justify-between">
                  <h2 className="text-2xl font-bold text-foreground">
                    {filteredMovies.length} {filteredMovies.length === 1 ? 'Movie' : 'Movies'} Found
                  </h2>
                </div>
                <div className="grid grid-cols-2 md:grid-cols-3 xl:grid-cols-4 gap-6">
                  {filteredMovies.map((movie, index) => (
                    <div
                      key={movie.id}
                      style={{ animationDelay: `${index * 0.05}s` }}
                    >
                      <MovieCard
                        movie={movie}
                        onClick={() => handleMovieClick(movie.id)}
                      />
                    </div>
                  ))}
                </div>
              </>
            )}
          </main>
        </div>
      </div>

      {/* Movie Details Modal */}
      <MovieModal
        movieId={selectedMovieId}
        open={modalOpen}
        onOpenChange={setModalOpen}
      />
    </div>
  );
};

export default Index;
