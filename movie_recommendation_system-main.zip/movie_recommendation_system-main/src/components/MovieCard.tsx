import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Star } from "lucide-react";

interface MovieCardProps {
  movie: {
    id: number;
    title: string;
    posterUrl: string;
    rating: string;
    year: string | number;
    language: string;
  };
  onClick: () => void;
}

export const MovieCard = ({ movie, onClick }: MovieCardProps) => {
  const getLanguageLabel = (lang: string) => {
    const labels: Record<string, string> = {
      en: "English",
      hi: "Hindi",
      ml: "Malayalam"
    };
    return labels[lang] || lang.toUpperCase();
  };

  return (
    <Card 
      className="group relative overflow-hidden cursor-pointer bg-card border-border hover:shadow-[var(--shadow-card-hover)] transition-all duration-300 animate-fade-in"
      onClick={onClick}
    >
      <div className="aspect-[2/3] overflow-hidden">
        <img
          src={movie.posterUrl}
          alt={movie.title}
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
          loading="lazy"
        />
      </div>
      
      <div className="absolute inset-0 bg-gradient-to-t from-background via-background/80 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300" />
      
      <div className="absolute bottom-0 left-0 right-0 p-4 translate-y-4 group-hover:translate-y-0 transition-transform duration-300">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-semibold text-foreground line-clamp-2 text-sm">
            {movie.title}
          </h3>
          <Badge variant="secondary" className="shrink-0 bg-secondary/90 text-secondary-foreground">
            <Star className="w-3 h-3 mr-1 fill-current" />
            {movie.rating}
          </Badge>
        </div>
        
        <div className="flex items-center gap-2 text-xs text-muted-foreground">
          <span>{movie.year}</span>
          <span>•</span>
          <span>{getLanguageLabel(movie.language)}</span>
        </div>
      </div>
    </Card>
  );
};
