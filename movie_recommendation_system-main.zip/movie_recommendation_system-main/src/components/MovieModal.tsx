import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Badge } from "@/components/ui/badge";
import { Star, Calendar, Film, Clock, User } from "lucide-react";
import { useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";

interface MovieDetails {
  id: number;
  title: string;
  posterUrl: string;
  rating: string;
  year: string | number;
  overview: string;
  language: string;
  genres: string[];
  runtime: string;
  cast: string[];
  director: string;
}

interface MovieModalProps {
  movieId: number | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}

export const MovieModal = ({ movieId, open, onOpenChange }: MovieModalProps) => {
  const [movie, setMovie] = useState<MovieDetails | null>(null);
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (movieId && open) {
      fetchMovieDetails();
    }
  }, [movieId, open]);

  const fetchMovieDetails = async () => {
    if (!movieId) return;
    
    setLoading(true);
    try {
      const { data, error } = await supabase.functions.invoke('get-movie-details', {
        body: { movieId }
      });

      if (error) throw error;
      setMovie(data);
    } catch (error) {
      console.error('Error fetching movie details:', error);
      toast.error('Failed to load movie details');
    } finally {
      setLoading(false);
    }
  };

  const getLanguageLabel = (lang: string) => {
    const labels: Record<string, string> = {
      en: "English",
      hi: "Hindi",
      ml: "Malayalam"
    };
    return labels[lang] || lang.toUpperCase();
  };

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto bg-card border-border">
        {loading && (
          <div className="flex items-center justify-center py-12">
            <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-primary"></div>
          </div>
        )}
        
        {!loading && movie && (
          <div className="animate-scale-in">
            <DialogHeader className="mb-4">
              <DialogTitle className="text-2xl font-bold text-foreground">{movie.title}</DialogTitle>
            </DialogHeader>
            
            <div className="grid md:grid-cols-3 gap-6">
              <div className="md:col-span-1">
                <img
                  src={movie.posterUrl}
                  alt={movie.title}
                  className="w-full rounded-lg shadow-[var(--shadow-card)]"
                />
              </div>
              
              <div className="md:col-span-2 space-y-4">
                <div className="flex flex-wrap items-center gap-2">
                  <Badge variant="secondary" className="bg-accent text-accent-foreground">
                    <Star className="w-4 h-4 mr-1 fill-current" />
                    {movie.rating} IMDB
                  </Badge>
                  <Badge variant="outline" className="border-border">
                    <Calendar className="w-4 h-4 mr-1" />
                    {movie.year}
                  </Badge>
                  <Badge variant="outline" className="border-border">
                    <Clock className="w-4 h-4 mr-1" />
                    {movie.runtime}
                  </Badge>
                  <Badge variant="outline" className="border-border">
                    {getLanguageLabel(movie.language)}
                  </Badge>
                </div>

                <div>
                  <h3 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                    <Film className="w-5 h-5 text-primary" />
                    Synopsis
                  </h3>
                  <p className="text-muted-foreground leading-relaxed">{movie.overview}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-foreground mb-2">Genres</h3>
                  <div className="flex flex-wrap gap-2">
                    {movie.genres.map((genre) => (
                      <Badge key={genre} variant="secondary" className="bg-muted text-muted-foreground">
                        {genre}
                      </Badge>
                    ))}
                  </div>
                </div>

                <div>
                  <h3 className="font-semibold text-foreground mb-2 flex items-center gap-2">
                    <User className="w-5 h-5 text-primary" />
                    Director
                  </h3>
                  <p className="text-muted-foreground">{movie.director}</p>
                </div>

                <div>
                  <h3 className="font-semibold text-foreground mb-2">Cast</h3>
                  <p className="text-muted-foreground">{movie.cast.join(", ")}</p>
                </div>
              </div>
            </div>
          </div>
        )}
      </DialogContent>
    </Dialog>
  );
};
