import { useState } from "react";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Slider } from "@/components/ui/slider";
import { Label } from "@/components/ui/label";
import { X, Filter } from "lucide-react";
import { Checkbox } from "@/components/ui/checkbox";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";

const GENRES = [
  { id: 28, name: "Action" },
  { id: 12, name: "Adventure" },
  { id: 16, name: "Animation" },
  { id: 35, name: "Comedy" },
  { id: 80, name: "Crime" },
  { id: 99, name: "Documentary" },
  { id: 18, name: "Drama" },
  { id: 10751, name: "Family" },
  { id: 14, name: "Fantasy" },
  { id: 36, name: "History" },
  { id: 27, name: "Horror" },
  { id: 10402, name: "Music" },
  { id: 9648, name: "Mystery" },
  { id: 10749, name: "Romance" },
  { id: 878, name: "Sci-Fi" },
  { id: 10770, name: "TV Movie" },
  { id: 53, name: "Thriller" },
  { id: 10752, name: "War" },
  { id: 37, name: "Western" },
];

interface FilterPanelProps {
  selectedGenres: number[];
  onGenreChange: (genres: number[]) => void;
  selectedLanguage: string;
  onLanguageChange: (language: string) => void;
  rating: number;
  onRatingChange: (rating: number) => void;
  yearRange: [number, number];
  onYearRangeChange: (range: [number, number]) => void;
  onReset: () => void;
}

export const FilterPanel = ({
  selectedGenres,
  onGenreChange,
  selectedLanguage,
  onLanguageChange,
  rating,
  onRatingChange,
  yearRange,
  onYearRangeChange,
  onReset,
}: FilterPanelProps) => {
  const toggleGenre = (genreId: number) => {
    if (selectedGenres.includes(genreId)) {
      onGenreChange(selectedGenres.filter(id => id !== genreId));
    } else {
      onGenreChange([...selectedGenres, genreId]);
    }
  };

  const removeGenre = (genreId: number) => {
    onGenreChange(selectedGenres.filter(id => id !== genreId));
  };

  return (
    <div className="space-y-6 p-6 bg-card rounded-lg border border-border animate-slide-up">
      <div className="flex items-center justify-between">
        <h2 className="text-xl font-bold text-foreground flex items-center gap-2">
          <Filter className="w-5 h-5 text-primary" />
          Filters
        </h2>
        <Button 
          variant="outline" 
          size="sm" 
          onClick={onReset}
          className="border-border hover:bg-muted"
        >
          Reset All
        </Button>
      </div>

      {/* Active Genres */}
      {selectedGenres.length > 0 && (
        <div className="flex flex-wrap gap-2">
          {selectedGenres.map(genreId => {
            const genre = GENRES.find(g => g.id === genreId);
            return genre ? (
              <Badge
                key={genreId}
                variant="secondary"
                className="bg-accent text-accent-foreground cursor-pointer hover:bg-accent/80 transition-colors"
                onClick={() => removeGenre(genreId)}
              >
                {genre.name}
                <X className="w-3 h-3 ml-1" />
              </Badge>
            ) : null;
          })}
        </div>
      )}

      {/* Genres */}
      <div className="space-y-3">
        <Label className="text-foreground font-semibold">Genres</Label>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-2">
          {GENRES.map((genre) => (
            <div key={genre.id} className="flex items-center space-x-2">
              <Checkbox
                id={`genre-${genre.id}`}
                checked={selectedGenres.includes(genre.id)}
                onCheckedChange={() => toggleGenre(genre.id)}
                className="border-border"
              />
              <label
                htmlFor={`genre-${genre.id}`}
                className="text-sm text-muted-foreground cursor-pointer hover:text-foreground transition-colors"
              >
                {genre.name}
              </label>
            </div>
          ))}
        </div>
      </div>

      {/* Language */}
      <div className="space-y-3">
        <Label className="text-foreground font-semibold">Language</Label>
        <RadioGroup value={selectedLanguage} onValueChange={onLanguageChange}>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="all" id="lang-all" />
            <label htmlFor="lang-all" className="text-sm text-muted-foreground cursor-pointer">
              All Languages
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="english" id="lang-en" />
            <label htmlFor="lang-en" className="text-sm text-muted-foreground cursor-pointer">
              English
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="hindi" id="lang-hi" />
            <label htmlFor="lang-hi" className="text-sm text-muted-foreground cursor-pointer">
              Hindi
            </label>
          </div>
          <div className="flex items-center space-x-2">
            <RadioGroupItem value="malayalam" id="lang-ml" />
            <label htmlFor="lang-ml" className="text-sm text-muted-foreground cursor-pointer">
              Malayalam
            </label>
          </div>
        </RadioGroup>
      </div>

      {/* IMDB Rating */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label className="text-foreground font-semibold">IMDB Rating</Label>
          <span className="text-sm text-muted-foreground">{rating.toFixed(1)}+</span>
        </div>
        <Slider
          value={[rating]}
          onValueChange={(values) => onRatingChange(values[0])}
          min={0}
          max={10}
          step={0.5}
          className="w-full"
        />
      </div>

      {/* Year Range */}
      <div className="space-y-3">
        <div className="flex items-center justify-between">
          <Label className="text-foreground font-semibold">Release Year</Label>
          <span className="text-sm text-muted-foreground">
            {yearRange[0]} - {yearRange[1]}
          </span>
        </div>
        <Slider
          value={yearRange}
          onValueChange={(values) => onYearRangeChange([values[0], values[1]])}
          min={1900}
          max={2025}
          step={1}
          className="w-full"
        />
      </div>
    </div>
  );
};
